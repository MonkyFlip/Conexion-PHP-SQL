// modificar_empleado_proceso.php
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "conexion_php";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_vehiculo = $_POST['id_vehiculo'];
    $placa_vehiculo = $_POST['placa_vehiculo'];
    $marca_vehiculo = $_POST['marca_vehiculo'];
    $tamaño_vehiculo = $_POST['tamaño_vehiculo'];
    $color_vehiculo = $_POST['color_vehiculo'];
    $modelo_vehiculo = $_POST['modelo_vehiculo'];

    $sql = "UPDATE vehiculo SET placa_vehiculo='$placa_vehiculo', marca_vehiculo='$marca_vehiculo', tamaño_vehiculo='$tamaño_vehiculo', color_vehiculo='$color_vehiculo', modelo_vehiculo='$modelo_vehiculo' WHERE id_vehiculo='$id_vehiculo'";

    if ($conn->query($sql) === TRUE) {
        header("Location:./consulta_vehiculo.php");
    } else {
        echo "Error actualizando el registro: ". $conn->error;
    }
}

$conn->close();