<?php
/*if(!$_POST){
    header('Location:Alta_vehiculo.html');
}*/

// Parametros de la conexion de la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "conexion_php";

// Creamos la conexion de la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

//Verificamos la conexion de la base de datos
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//Obtener la identificación máxima de la base de datos
$sql = "SELECT MAX(id_vehiculo) as max_id FROM vehiculo";
$result = $conn->query($sql);

// Generar el siguiente id_vehiculo
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $_id = $row['max_id'] + 1;
} else {
    $_id = 1; // Si no hay registros en la tabla, comience con el ID 1
}

// Insertar el nuevo vehículo en la base de datos.
if ($_POST  ){
$placa_vehiculo = $_POST['placa_vehiculo'];
$marca_vehiculo = $_POST['marca_vehiculo'];
$tamaño_vehiculo = $_POST['tamaño_vehiculo'];
$color_vehiculo = $_POST['color_vehiculo'];
$modelo_vehiculo = $_POST['modelo_vehiculo'];

$insert_sql = "INSERT INTO vehiculo (id_vehiculo, placa_vehiculo, marca_vehiculo, tamaño_vehiculo, color_vehiculo, modelo_vehiculo)
VALUES ($_id, '$placa_vehiculo', '$marca_vehiculo', '$tamaño_vehiculo', '$color_vehiculo', '$modelo_vehiculo')";

    if ($conn->query($insert_sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $insert_sql . "<br>" . $conn->error;
    }
}

// Recuperar los vehículos de la base de datos.
$sql = "SELECT id_vehiculo, placa_vehiculo, marca_vehiculo, tamaño_vehiculo, color_vehiculo, modelo_vehiculo FROM vehiculo";
$result = $conn->query($sql);

// Cerramos la conexion de la base de datos
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CONSULTA DE VEHICULOS</title>
    <link rel="stylesheet" href="../DISEÑOS DE CONSULTAS/head.css">
    <link rel="icon" href="./consulta-vehiculo.png">
</head>
<body>
    <style>
        body{
            background-color: rgb(254, 231, 217);
        }
    </style>
    <div class="container">
        <!-- Barra de navegación lateral -->
        <div class="row">
            <div class="col-md-2">
                <nav class="navbar navbar-default sidebar" role="navigation">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-sidebar-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="./consulta_vehiculo.php">
                            <img src="./consulta-vehiculo.png" alt="Logo" width="70">
                        </a>
                    </div>
                    <div class="collapse navbar-collapse" id="bs-sidebar-navbar-collapse-1">
                        <ul class="nav navbar-nav">
                            <h2>Lo Maizimo</h2>
                            <li><a href="#">Inicio</a></li>
                            <li><a href="../PRODUCTOS/consulta_productos.php">Productos</a></li>
                            <li><a href="./consulta_vehiculo.php">Vehiculos</a></li>
                            <li><a href="../EMPLEADOS/consulta_empleado.php">Empleados</a></li>
                            <li><a href="#">Sucursales</a></li>
                            <li><a href="#">Servicios</a></li>
                            <li><a href="#">Clientes</a></li>
                            <li><a href="#">Pedidos</a></li>
                            <li><a href="#">Repartidores</a></li>
                            <li><a href="#">Paquetes</a></li>
                            <!-- Agrega más enlaces según tus necesidades -->
                        </ul>
                    </div>
                </nav>
            </div>
            <div class="col-md-10">
                <!-- Tabla de productos -->
                <h1>CONSULTA DE VEHICULOS</h1>
                <a href="./alta_vehiculo.html"><img src="../ELEMENTOS DE CONSULTA/agregar.png" width="30"></a>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Placa</th>
                            <th>Marca</th>
                            <th>Tamaño</th>
                            <th>Color</th>
                            <th>Modelo</th>
                            <th>Editar</th>
                            <th>Eliminar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Aquí puedes agregar filas con datos de productos -->
                        <?php
                        while($row = $result->fetch_assoc())
                        {
                            echo "<tr>";
                            echo "<td>".$row["id_vehiculo"]. "</td>";
                            echo "<td>". $row["placa_vehiculo"]. "</td>";
                            echo "<td>". $row["marca_vehiculo"]. "</td>";
                            echo "<td>". $row["tamaño_vehiculo"]. "</td>";
                            echo "<td>". $row["color_vehiculo"]. "</td>";
                            echo "<td>". $row["modelo_vehiculo"]. "</td>";
                            echo '<td><a href="./modificar_vehiculo.php"><img src="../ELEMENTOS DE CONSULTA/modificar.png" width="30"></a></td>';
                            echo '<td><a href="./eliminar_vehiculo.php?id_vehiculo='. $row["id_vehiculo"] .'"><img src="../ELEMENTOS DE CONSULTA/eliminar.png" width="25"></a></td>';
                        }
                        ?>
                        <!-- Agrega más filas según las necesidades -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Scripts de Bootstrap y jQuery -->
    <script src="../BOOTSTRAP Y JQUERY PARA CONSULTAS/script_1.js"></script>
    <script src="../BOOTSTRAP Y JQUERY PARA CONSULTAS/script_2.js"></script>
</body>
</html>
