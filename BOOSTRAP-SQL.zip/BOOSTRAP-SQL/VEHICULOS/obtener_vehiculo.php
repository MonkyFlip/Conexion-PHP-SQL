<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "conexion_php";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if (isset($_GET['id_vehiculo'])) {
    $id_vehiculo = $_GET['id_vehiculo'];
    $sql = "SELECT * FROM vehiculo WHERE id_vehiculo = '$id_vehiculo'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo json_encode($result->fetch_assoc());
    } else {
        echo json_encode([]);
    }
}

$conn->close();