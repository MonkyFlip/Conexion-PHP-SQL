<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Registro de Vehiculos</title>
    <!-- Agrega el enlace a Bootstrap CSS -->
    <link rel="stylesheet" href="../DISEÑOS/diesño_head.css">
    <style>
        body{
            background-color: #caf8cf;
        }
        /* Estilos personalizados para el cuadro del formulario */
        .custom-form-box {
            background-color: #ffffff;
            border: 1px solid #dddddd;
            border-radius: 10px;
            padding: 20px;
        }
        .btn-regresar {
            background-color: #ff0000;
            color: #ffffff;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <!-- Columna izquierda con la imagen -->
            <div class="col-md-6">
                <img src="./modificar-vehiculo.png" alt="Imagen del empleado" class="img-fluid">
            </div>
            <!-- Columna derecha con el formulario -->
            <div class="col-md-6">
                <div class="custom-form-box">
                    <h2> Modificar Registro de Vehiculos</h2>
                    <form id="registroForm" onsubmit="return validarFormulario()" method="post" action="./modificar_vehiculo_proceso.php">                        
                        <div class="form-group">
                            <label for="id_vehiculo">ID Vehiculo:</label>
                            <input type="text" name="id_vehiculo" class="form-control" id="id_vehiculo">
                        </div>
                        <div class="form-group">    
                            <label for="nombre">Placa:</label>
                            <input type="text" class="form-control" id="nombre" name="placa_vehiculo" placeholder="Ingresa la placa del vehiculo">
                        </div>
                        <div class="form-group">
                            <label for="nombre">Marca:</label>
                            <input type="text" class="form-control" name="marca_vehiculo" id="nombre" placeholder="Marca del vehiculo">
                        </div>
                        <div class="form-group">
                            <label for="puesto">Tamaño:</label>
                            <input type="text" class="form-select" id="puesto" name="tamaño_vehiculo">
                        </div>
                        <div class="form-group">
                            <label for="nombre">Color:</label>
                            <input type="text" class="form-control" name="color_vehiculo" id="nombre" placeholder="Color del vehiculo">
                        </div>
                        <div class="form-group">
                            <label for="nombre">Modelo:</label>
                            <input type="text" class="form-control" name="modelo_vehiculo" id="nombre" placeholder="Modelo del vehiculo">
                        </div>
                        <button type="submit" class="btn btn-primary">Registrar</button>
                    </form>
                    <p id="mensajeError" style="color: red;"></p>
                    <button onclick="window.location='./consulta_vehiculo.php'" class="btn btn-regresar mt-3">Cancelar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Agrega el enlace a Bootstrap JS (opcional) -->
    <script src="../DISEÑOS/script_1.js"></script>
    <script src="../DISEÑOS/script_2.js"></script>
    <script src="../DISEÑOS/script_3.js"></script>
    <script>
        // Se ejecuta al cargar la página y carga los datos del vehiculo en el formulario al seleccionar el id del vehiculo
        $(document).ready(function() {
            $('#id_vehiculo').on('blur', function() {
                cargarVehiculo();
            });
        });

        // Esta función se ejecuta al cargar la página y carga los datos del vehiculo en el formulario
        function cargarVehiculo() {
            const id_vehiculo = document.getElementById('id_vehiculo').value;
            if (id_vehiculo.trim()!== '') {
                $.ajax({
                    url: './obtener_vehiculo.php',
                    type: 'GET',
                    data: { id_vehiculo: id_vehiculo },
                    success: function(response) {
                        const vehiculo = JSON.parse(response);
                        if (vehiculo) {
                            document.getElementById('nombre').value = vehiculo.placa_vehiculo;
                            document.getElementById('marca_vehiculo').value = vehiculo.marca_vehiculo;
                            document.getElementById('tamaño_vehiculo').value = vehiculo.tamaño_vehiculo;
                            document.getElementById('color_vehiculo').value = vehiculo.color_vehiculo;
                            document.getElementById('modelo_vehiculo').value = vehiculo.modelo_vehiculo;
                        } else {
                            alert('Vehiculo no encontrado');
                            }
                        },
                        error: function(xhr, status, error) {
                        console.error('Error en la solicitud AJAX:', error);
                    }
                });
            }
        }

        function validarFormulario() {
            const nombre = document.getElementById('nombre').value;
            // Agrega más validaciones para otros campos si es necesario
            if (nombre.trim() === '') {
                document.getElementById('mensajeError').textContent = 'Por favor, completa todos los campos.';
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
