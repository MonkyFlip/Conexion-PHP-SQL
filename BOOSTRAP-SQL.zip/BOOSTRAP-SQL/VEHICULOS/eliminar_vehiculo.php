<?php
// Parámetros de conexión
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "conexion_php";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Comprobar la conexión
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//obtner el id_vehiculo de la URL
$id_vehiculo = $_GET['id_vehiculo'];

//Eliminar el registro del vehiculo
$sql = "DELETE FROM vehiculo WHERE id_vehiculo=$id_vehiculo";

if ($conn->query($sql) === TRUE) {
    echo "Registro eliminado correctamente";
} else {
    echo "Error eliminando el registro: " . $conn->error;
}

$conn->close();

// Redireccionar a la página de consulta de vehículos
header("Location: consulta_vehiculo.php");
exit();