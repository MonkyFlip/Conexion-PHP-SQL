<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "conexion_php";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if (isset($_GET['id_producto'])) {
    $id_producto = $_GET['id_producto'];
    $sql = "SELECT * FROM producto WHERE id_producto = '$id_producto'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo json_encode($result->fetch_assoc());
    } else {
        echo json_encode([]);
    }
}

$conn->close();