<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Registro de Productos</title>
    <!-- Agrega el enlace a Bootstrap CSS -->
    <link rel="stylesheet" href="../DISEÑOS/diesño_head.css">
    <style>
        body{
            background-color: #caf8cf;
        }
        /* Estilos personalizados para el cuadro del formulario */
        .custom-form-box {
            background-color: #ffffff;
            border: 1px solid #dddddd;
            border-radius: 10px;
            padding: 20px;
        }
        .btn-regresar {
            background-color: #ff0000;
            color: #ffffff;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <!-- Columna izquierda con la imagen -->
            <div class="col-md-6">
                <img src="./modificar-producto.png" alt="Imagen del empleado" class="img-fluid">
            </div>
            <!-- Columna derecha con el formulario -->
            <div class="col-md-6">
                <div class="custom-form-box">
                    <h2>Modificar Registro de Productos</h2>
                    <form id="registroForm" onsubmit="return validarFormulario()" method="post" action="./modificar_producto_proceso.php">
                        <div class="form-group">
                            <label for="id_producto">ID Producto:</label>
                            <input type="text" name="id_producto" class="form-control" id="id_producto">
                        </div>
                        <div class="form-group">
                            <label for="nombre">Nombre:</label>
                            <input type="text" name="Nombre_producto" class="form-control" id="nombre" placeholder="Ingresa el nombre del producto">
                        </div>
                        <div class="form-group">
                            <label for="nombre">Cantidad:</label>
                            <input type="text" name="catidad_producto" class="form-control" id="nombre" placeholder="Descripcion del producto">
                        </div>
                        <div class="form-group">
                            <label for="nombre">Precio:</label>
                            <input type="text" name="precio_producto" class="form-control" id="nombre" placeholder="Precio del producto">
                        </div>
                        <button type="submit" class="btn btn-primary">Registrar</button>
                    </form>
                    <p id="mensajeError" style="color: red;"></p>
                    <button onclick="window.location='./consulta_productos.php'" class="btn btn-regresar mt-3">Cancelar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Agrega el enlace a Bootstrap JS (opcional) -->
    <script src="../DISEÑOS/script_1.js"></script>
    <script src="../DISEÑOS/script_2.js"></script>
    <script src="../DISEÑOS/script_3.js"></script>
    <script>
        //en este script validaremos la existencia del id del producto que queremos modificar
        //crearemos la funcion para cargar el producto
        $(document).ready(function() {
            $('#id_producto').on('blur', function() {
                cargargProducto();
            });
        });

        //Haremos uso de la funcion para localizar el producto con su id
        function cargProducto() {
            const id_producto = document.getElementById('id_producto').value;
            if(id_producto.trim() !== ''){
                $.ajax({
                    url: './obtener_producto.php',
                    type: 'GET',
                    data: { id_producto: id_producto},
                    success: function(response){
                        console.log(response); //esto es para depurarlo
                        const producto = JSON.parse(response);
                        if (producto && Object.keys(producto).length > 0){
                            $('#Nombre_producto').val(producto.Nombre_producto);
                            $('#catidad_producto').val(producto.catidad_producto);
                            $('#precio_producto').val(producto.precio_producto);
                        } else {
                            alert('Producto no encontrado');
                        }
                    },
                    error: function(xhr, status, error){
                        console.log('Error en la solicitud AJAX:', error);
                    }
                });
            }
        }
        
        function validarFormulario() {
            const nombre = document.getElementById('nombre').value;
            // Agrega más validaciones para otros campos si es necesario
            if (nombre.trim() === '') {
                document.getElementById('mensajeError').textContent = 'Por favor, completa todos los campos.';
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
