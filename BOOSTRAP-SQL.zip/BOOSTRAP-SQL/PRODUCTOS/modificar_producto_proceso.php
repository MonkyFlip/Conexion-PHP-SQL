<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "conexion_php";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_producto = $_POST['id_producto'];
    $Nombre_producto = $_POST['Nombre_producto'];
    $catidad_producto = $_POST['catidad_producto'];
    $precio_producto = $_POST['precio_producto'];

    $sql = "UPDATE producto SET Nombre_producto='$Nombre_producto', catidad_producto='$catidad_producto', precio_producto='$precio_producto' WHERE id_producto='$id_producto'";
    
    if ($conn->query($sql) === TRUE) {
        header("Location: ./consulta_productos.php");
    } else {
        echo "Error actualizando el registro: " . $conn->error;
    }
}

$conn->close();
