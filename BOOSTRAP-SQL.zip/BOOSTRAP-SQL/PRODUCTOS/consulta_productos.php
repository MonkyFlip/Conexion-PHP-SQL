<?php
/*if(!$_POST){
    header('Location:alta_productos.html');
}*/

// Parametro de la conexion de la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "conexion_php";

// Creamos la conexion de la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

//Verifica la conexion de la base de datos
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Obtener la identificación máxima de la base de datos
$sql = "SELECT MAX(id_producto) as max_id FROM producto";
$result = $conn->query($sql);
$id_row = $result->fetch_assoc();
$_id = $id_row['max_id'] + 1;

// Ejecutar la consulta para los campos de la tabla
$sql = "SELECT id_producto, Nombre_producto, catidad_producto, precio_producto FROM producto";
$result = $conn->query($sql);

// Obtenga los datos POST y verifique si los datos POST ya existen en la base de datos
if ($_POST) {
    $Nombre_producto = $_POST['Nombre_producto'];
    $catidad_producto = $_POST['catidad_producto'];
    $precio_producto = $_POST['precio_producto'];

    // Insertar los datos recibidos en la base de datos.
    $insert_sql = "INSERT INTO producto (id_producto, Nombre_producto, catidad_producto, precio_producto) 
    VALUES ($_id, '$Nombre_producto', '$catidad_producto', '$precio_producto')";

    if ($conn->query($insert_sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $insert_sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CONSULTA DE PRODUCTOS</title>
    <link rel="stylesheet" href="../DISEÑOS DE CONSULTAS/head.css">
    <link rel="icon" href="./consulta-producto.png">
</head>
<body>
    <style>
        body{
            background-color: rgb(254, 231, 217);
        }
    </style>
    <div class="container">
        <!-- Barra de navegación lateral -->
        <div class="row">
            <div class="col-md-2">
                <nav class="navbar navbar-default sidebar" role="navigation">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-sidebar-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="./consulta_productos.php">
                            <img src="./consulta-producto.png" alt="Logo" width="70">
                        </a>
                    </div>
                    <div class="collapse navbar-collapse" id="bs-sidebar-navbar-collapse-1">
                        <ul class="nav navbar-nav">
                            <h2>Lo Maizimo</h2>
                            <li><a href="#">Inicio</a></li>
                            <li><a href="./consulta_productos.php">Productos</a></li>
                            <li><a href="../VEHICULOS/consulta_vehiculo.php">Vehiculos</a></li>
                            <li><a href="../EMPLEADOS/consulta_empleado.php">Empleados</a></li>
                            <li><a href="#">Sucursales</a></li>
                            <li><a href="#">Servicios</a></li>
                            <li><a href="#">Clientes</a></li>
                            <li><a href="#">Pedidos</a></li>
                            <li><a href="#">Repartidores</a></li>
                            <li><a href="#">Paquetes</a></li>
                            <!-- Agrega más enlaces según tus necesidades -->
                        </ul>
                    </div>
                </nav>
            </div>
            <div class="col-md-10">
                <!-- Tabla de productos -->
                <h1>CONSULTA DE PRODUCTOS</h1>
                <a href="./alta_productos.html"><img src="../ELEMENTOS DE CONSULTA/agregar.png" width="30"></a>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Precio</th>
                            <th>Editar</th>
                            <th>Eliminar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Aquí puedes agregar filas con datos de productos -->
                        <?php
                        while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id_producto'] . "</td>";
                        echo "<td>" . $row['Nombre_producto'] . "</td>";
                        echo "<td>" . $row['catidad_producto'] . "</td>";
                        echo "<td>" . $row['precio_producto'] . "</td>";
                        echo '<td><a href="./modificar_productos.php"><img src="../ELEMENTOS DE CONSULTA/modificar.png" width="30"></a></td>';
                        echo '<td><a href="./eliminar_producto.php?id_producto='. $row["id_producto"] .'"><img src="../ELEMENTOS DE CONSULTA/eliminar.png" width="25"></a></td>';                        echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Scripts de Bootstrap y jQuery -->
    <script src="../BOOTSTRAP Y JQUERY PARA CONSULTAS/script_1.js"></script>
    <script src="../BOOTSTRAP Y JQUERY PARA CONSULTAS/script_2.js"></script>
</body>
</html>
