<?php
// Parámetros de conexión
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "conexion_php";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Comprobar la conexión
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Obtener el id_producto de la URL
$id_producto = $_GET['id_producto'];

//Eliminar el registro de empleado
$sql = "DELETE FROM producto WHERE id_producto = $id_producto";

if ($conn->query($sql) === TRUE) {
    echo "Registro eliminado correctamente";
} else {
    echo "Error al eliminar el registro: " . $conn->error;
}

$conn->close();

// Redireccionar a la página de consulta de productos
header("Location: consulta_productos.php");
exit();