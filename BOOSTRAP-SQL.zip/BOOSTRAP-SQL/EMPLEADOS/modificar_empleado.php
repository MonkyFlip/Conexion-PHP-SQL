<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Registro de Empleado</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../DISEÑOS/diesño_head.css">
    <style>
        body {
            background-color: #caf8cf;
        }
        .custom-form-box {
            background-color: #ffffff;
            border: 1px solid #dddddd;
            border-radius: 10px;
            padding: 20px;
        }
        .btn-regresar {
            background-color: #ff0000;
            color: #ffffff;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/themes/base/jquery-ui.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6">
                <img src="./modificar-empleado.png" alt="Imagen del empleado" class="img-fluid">
            </div>
            <div class="col-md-6">
                <div class="custom-form-box">
                    <h2>Modificar Registro de Empleado</h2>
                    <form id="registroForm" onsubmit="return validarFormulario()" method="post" action="./modificar_empleado_proceso.php">
                        <div class="form-group">
                            <label for="id_empleado">ID Empleado:</label>
                            <input type="text" name="id_empleado" class="form-control" id="id_empleado">
                        </div>
                        <div class="form-group">
                            <label for="nombre_empleado">Nombre:</label>
                            <input type="text" name="nombre_empleado" class="form-control" id="nombre_empleado" placeholder="Ingresa tu nombre">
                        </div>
                        <div class="form-group">
                            <label for="ap_pat_empleado">Apellido Paterno:</label>
                            <input type="text" name="ap_pat_empleado" class="form-control" id="ap_pat_empleado" placeholder="Ingresa tus Apellidos">
                        </div>
                        <div class="form-group">
                            <label for="ap_mat_empleado">Apellido Materno:</label>
                            <input type="text" name="ap_mat_empleado" class="form-control" id="ap_mat_empleado" placeholder="Ingresa tus Apellidos">
                        </div>
                        <div class="form-group">
                            <label for="puesto">Puesto:</label>
                            <select class="form-select" name="puesto" id="puesto">
                                <option value="Repartidor">Repartidor</option>
                                <option value="Molinero">Molinero</option>
                                <option value="Cajero">Cajero</option>
                                <option value="Gerente">Gerente</option>
                                <option value="Empacador">Empacador</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="horas_trabajo">Horas de Trabajo:</label>
                            <input type="text" name="horas_trabajo" class="form-control" id="horas_trabajo" placeholder="Ingresa tus horas de trabajo">
                        </div>
                        <div class="form-group">
                            <label for="sueldo">Sueldo:</label>
                            <input type="text" name="sueldo" class="form-control" id="sueldo" placeholder="Ingresa tu sueldo">
                        </div>
                        <p>Recuerda que los datos ingresados serán almacenados en la base de datos.</p>
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="terminosCondiciones">
                            <label class="form-check-label" for="terminosCondiciones">Acepto los términos y condiciones</label>
                        </div>
                        <button type="submit" class="btn btn-primary">Actualizar</button>
                    </form>
                    <p id="mensajeError" style="color: red;"></p>
                    <button onclick="window.location='./consulta_empleado.php'" class="btn btn-regresar mt-3">Cancelar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="../DISEÑOS/script_1.js"></script>
    <script src="../DISEÑOS/script_2.js"></script>
    <script src="../DISEÑOS/script_3.js"></script>
    <script>
                // Se ejecuta al cargar la página y carga los datos del vehiculo en el formulario al seleccionar el id del empleado
        $(document).ready(function() {
            $('#id_empleado').on('blur', function() {
                cargarEmpleado();
            });
        });

                // Esta función se ejecuta al cargar la página y carga los datos del empleado en el formulario
        function cargarEmpleado() {
            const id_empleado = document.getElementById('id_empleado').value;
            if (id_empleado.trim() !== '') {
                $.ajax({
                    url: './obtener_empleado.php',
                    type: 'GET',
                    data: { id_empleado: id_empleado },
                    success: function(response) {
                        console.log(response); // Agrega esto para depuración
                        const empleado = JSON.parse(response);
                        if (empleado && Object.keys(empleado).length > 0) {
                            $('#nombre_empleado').val(empleado.nombre_empleado);
                            $('#ap_pat_empleado').val(empleado.ap_pat_empleado);
                            $('#ap_mat_empleado').val(empleado.ap_mat_empleado);
                            $('#puesto').val(empleado.puesto);
                            $('#horas_trabajo').val(empleado.horas_trabajo);
                            $('#sueldo').val(empleado.sueldo);
                        } else {
                            alert('Empleado no encontrado');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error en la solicitud AJAX:', error);
                    }
                });
            }
        }

        function validarFormulario() {
            const nombre = document.getElementById('nombre_empleado').value;
            if (nombre.trim() === '') {
                document.getElementById('mensajeError').textContent = 'Por favor, completa todos los campos.';
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
