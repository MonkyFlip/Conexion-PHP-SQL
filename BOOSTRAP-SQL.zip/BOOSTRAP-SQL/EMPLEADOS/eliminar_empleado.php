<?php
// Parámetros de conexión
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "conexion_php";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Comprobar la conexión
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Obtener el id_empleado de la URL
$id_empleado = $_GET['id_empleado'];

// Eliminar el registro de empleado
$sql = "DELETE FROM empleado WHERE id_empleado=$id_empleado";

if ($conn->query($sql) === TRUE) {
    echo "Registro eliminado correctamente";
} else {
    echo "Error al eliminar el registro: " . $conn->error;
}

$conn->close();

// Redireccionar a la página de consulta de empleados
header("Location: consulta_empleado.php");
exit();
?>