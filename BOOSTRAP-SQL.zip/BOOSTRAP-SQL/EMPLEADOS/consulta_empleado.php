<?php
/*if(!$_POST){
    header('Location:alta_empleado.html');
}*/

// Parametros de la conexion de la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "conexion_php";

// Creamos la conexion de la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

//Verifica la conexion de la base de datos
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Obtener la identificación máxima de la base de datos
$sql = "SELECT MAX(id_empleado) as max_id FROM empleado";
$result = $conn->query($sql);
$id_row = $result->fetch_assoc();
$_id = $id_row['max_id'] + 1;

// Ejecutar la consulta para los campos de la tabla
$sql = "SELECT id_empleado, nombre_empleado, Ap_pat_empleado, Ap_mat_empleado, puesto, horas_trabajo, sueldo FROM empleado";
$result = $conn->query($sql);

// Obtenga los datos POST y verifique si los datos POST ya existen en la base de datos
if ($_POST) {
    $nombre_empleado = $_POST['nombre_empleado'];
    $Ap_pat_empleado = $_POST['Ap_pat_empleado'];
    $Ap_mat_empleado = $_POST['Ap_mat_empleado'];
    $puesto = $_POST['puesto'];
    $horas_trabajo = $_POST['horas_trabajo'];
    $sueldo = $_POST['sueldo'];

   // Insertar los datos recibidos en la base de datos.
    $insert_sql = "INSERT INTO empleado (id_empleado, nombre_empleado, Ap_pat_empleado, Ap_mat_empleado, puesto, horas_trabajo, sueldo) 
    VALUES ($_id, '$nombre_empleado', '$Ap_pat_empleado', '$Ap_mat_empleado', '$puesto', '$horas_trabajo', '$sueldo')";

    if ($conn->query($insert_sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $insert_sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CONSULTA DE EMPLEADOS</title>
    <link rel="stylesheet" href="../DISEÑOS DE CONSULTAS/head.css">
    <link rel="icon" href="./consulta-empleado.png">
</head>
<body>
    <style>
        body{
            background-color: rgb(254, 231, 217);
        }
    </style>
    <div class="container">
        <!-- Barra de navegación lateral -->
        <div class="row">
            <div class="col-md-2">
                <nav class="navbar navbar-default sidebar" role="navigation">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-sidebar-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="./consulta_empleado.php">
                            <img src="./consulta-empleado.png" alt="Logo" width="70">
                        </a>
                    </div>
                    <div class="collapse navbar-collapse" id="bs-sidebar-navbar-collapse-1">
                        <ul class="nav navbar-nav">
                            <h2>Lo Maizimo</h2>
                            <h5>Consultas, Altas y Modificaciones</h5>
                            <li><a href="#">Inicio</a></li>
                            <li><a href="../PRODUCTOS/consulta_productos.php">Productos</a></li>
                            <li><a href="../VEHICULOS/consulta_vehiculo.php">Vehiculos</a></li>
                            <li><a href="./consulta_empleado.php">Empleados</a></li>
                            <li><a href="#">Sucursales</a></li>
                            <li><a href="#">Servicios</a></li>
                            <li><a href="#">Clientes</a></li>
                            <li><a href="#">Pedidos</a></li>
                            <li><a href="#">Repartidores</a></li>
                            <li><a href="#">Paquetes</a></li>
                            <!-- Agrega más enlaces según tus necesidades -->
                        </ul>
                    </div>
                </nav>
            </div>
            <div class="col-md-10">
                <!-- Tabla de productos -->
                <h1>CONSULTA DE EMPLEADOS</h1>
                <a href="./alta_empleado.html"><img src="../ELEMENTOS DE CONSULTA/agregar.png" width="30"></a>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre(s)</th>
                            <th>Apellido Paterno</th>
                            <th>Apellido Materno</th>
                            <th>Puesto</th>
                            <th>Horas de trabajo</th>
                            <th>Sueldo</th>
                            <th>Editar</th>
                            <th>Eliminar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Aquí puedes agregar filas con datos de productos -->
                        <?php
                        while($row = $result->fetch_assoc())
                        {
                            echo "<tr>";
                                echo "<td>". $row["id_empleado"]. "</td>";
                                echo "<td>". $row["nombre_empleado"]. "</td>";
                                echo "<td>". $row["Ap_pat_empleado"]. "</td>";
                                echo "<td>". $row["Ap_mat_empleado"]. "</td>";
                                echo "<td>". $row["puesto"]. "</td>";
                                echo "<td>". $row["horas_trabajo"]. "</td>";
                                echo "<td>". $row["sueldo"]. "</td>";
                                echo '<td><a href="./modificar_empleado.php"><img src="../ELEMENTOS DE CONSULTA/modificar.png" width="30"></a></td>';
                                echo '<td><a href="./eliminar_empleado.php?id_empleado='. $row["id_empleado"] .'"><img src="../ELEMENTOS DE CONSULTA/eliminar.png" width="25"></a></td>';                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Scripts de Bootstrap y jQuery -->
    <script src="../BOOTSTRAP Y JQUERY PARA CONSULTAS/script_1.js"></script>
    <script src="../BOOTSTRAP Y JQUERY PARA CONSULTAS/script_2.js"></script>
</body>
</html>
