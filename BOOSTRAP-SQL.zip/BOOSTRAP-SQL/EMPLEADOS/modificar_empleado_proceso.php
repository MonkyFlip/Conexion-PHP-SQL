// modificar_empleado_proceso.php
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "conexion_php";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_empleado = $_POST['id_empleado'];
    $nombre_empleado = $_POST['nombre_empleado'];
    $ap_pat_empleado = $_POST['ap_pat_empleado'];
    $ap_mat_empleado = $_POST['ap_mat_empleado'];
    $puesto = $_POST['puesto'];
    $horas_trabajo = $_POST['horas_trabajo'];
    $sueldo = $_POST['sueldo'];

    $sql = "UPDATE empleado SET nombre_empleado='$nombre_empleado', ap_pat_empleado='$ap_pat_empleado', ap_mat_empleado='$ap_mat_empleado', puesto='$puesto', horas_trabajo='$horas_trabajo', sueldo='$sueldo' WHERE id_empleado='$id_empleado'";

    if ($conn->query($sql) === TRUE) {
        header("Location: ./consulta_empleado.php");
    } else {
        echo "Error actualizando el registro: " . $conn->error;
    }
}

$conn->close();
?>
